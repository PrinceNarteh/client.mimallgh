"use strict";
exports.id = 621;
exports.ids = [621];
exports.modules = {

/***/ 8515:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export axiosAuth */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const BASE_URL = "http://localhost:4000" || 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
}));
const axiosAuth = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 621:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dg": () => (/* binding */ getAllProducts),
/* harmony export */   "Xp": () => (/* binding */ getProducts),
/* harmony export */   "wv": () => (/* binding */ getProduct)
/* harmony export */ });
/* harmony import */ var _lib_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8515);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_axios__WEBPACK_IMPORTED_MODULE_0__]);
_lib_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getProduct = async (productId)=>{
    try {
        const products = await _lib_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/${productId}`);
        return products.data;
    } catch (error) {
        return null;
    }
};
const getAllProducts = async (search = "")=>{
    try {
        let products;
        if (search) {
            products = await _lib_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products?${search}`);
        } else {
            products = await _lib_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products`);
        }
        return products.data;
    } catch (error) {
        return null;
    }
};
const getProducts = async ()=>{
    try {
        const products = await _lib_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/category");
        return products.data;
    } catch (error) {
        return null;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;