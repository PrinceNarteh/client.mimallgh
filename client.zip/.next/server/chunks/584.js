"use strict";
exports.id = 584;
exports.ids = [584];
exports.modules = {

/***/ 7584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "j": () => (/* binding */ Error)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/images/something-went-wrong.png
/* harmony default export */ const something_went_wrong = ({"src":"/_next/static/media/something-went-wrong.6a2fea2f.png","height":606,"width":676,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA6klEQVR42mMAAXk2M5+4jMp53fPXnfKJzusvT8yv+r57nxADDCQk5y9zsfL8b8ig/J+BQfb/6f6J//9s37mUAQQe/f9vMHnLqcdxTQv+pzXP/xPVMO/XjFkb/1x98vn/mU//sxlOv/57+eDzv/83P/jzY/b1f/9W3//3f/OTf//3P/31//jzXy8Ydt751Lzt+rv/Bx59+7/rzpf/ly4/fnnp9qv3hx5++7/j9sfFDCCw5sQtx1UnH+TuOHHD42lVvOLptZv11p28E9K2ZAcnQ33fLHYGBgZeIBYEYnkGvwRVIC0GxDx2DAzsABJdeeAqh8boAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Error.tsx




const Error = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen grid place-content-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: something_went_wrong,
            alt: "",
            className: "max-w-sm"
        })
    });
};


/***/ })

};
;