"use strict";
exports.id = 584;
exports.ids = [584];
exports.modules = {

/***/ 7584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "j": () => (/* binding */ Error)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/images/something-went-wrong.png
/* harmony default export */ const something_went_wrong = ({"src":"/_next/static/media/something-went-wrong.6a2fea2f.png","height":606,"width":676,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAaVBMVEVQXl684vav5P+v1/M3OELNtcCtxtkqJzBccIxQUmej2/w4M0mxzN6t1vHLs7zQ9P/K1+rklo+bwdrL0uKDiaD8u77B5/xkVWiHoLlrdIfa/P83NEnd//8tLS3C6//b6vm/jpjQ+v9IQ1q5umYOAAAAHnRSTlMCdP7+JBZPFv2g/fxflzbG6yd46fut/oTmxbdTNg2M3qMpAAAACXBIWXMAABJ0AAASdAHeZh94AAAAP0lEQVR4nAXBhQHAIBAAsaPII3VXKvsP2QSOsIXFAuFL6ZngXL33463Y3xiLIjcoPeuhzRW43nV1aUHEGJHrB1+0AtMmt9XwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Error.tsx




const Error = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen grid place-content-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: something_went_wrong,
            alt: "",
            className: "max-w-sm"
        })
    });
};


/***/ })

};
;