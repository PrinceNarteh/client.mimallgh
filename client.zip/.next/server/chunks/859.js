"use strict";
exports.id = 859;
exports.ids = [859];
exports.modules = {

/***/ 7859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "GP": () => (/* reexport */ CustomLinks),
  "wp": () => (/* reexport */ Navbar),
  "E1": () => (/* reexport */ SearchBar),
  "M$": () => (/* reexport */ SectionHeader)
});

// UNUSED EXPORTS: FloatingNavbar, MainNavbar, NavItem, SubNavbar

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
;// CONCATENATED MODULE: ./components/layout/CustomLinks.tsx





const customLinks = [
    {
        label: "Home",
        link: "/"
    },
    {
        label: "Category",
        link: "/category"
    },
    {
        label: "Top Deals",
        link: "/top-deals"
    },
    {
        label: "Product Videos",
        link: "/product-videos"
    },
    {
        label: "Trending",
        link: "/trending"
    },
    {
        label: "More",
        link: "/more"
    }
];
const CustomLinks = ()=>{
    const { pathname  } = (0,router_.useRouter)();
    const links = customLinks.filter((link)=>pathname === "/" || !link.link.startsWith(pathname));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between flex-wrap py-3 text-center shadow-md md:divide-y-0 md:divide-x-2 md:text-xl z-30",
        children: [
            links.map((link, idx)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: link.link,
                    className: "px-10 hover:text-pink-500",
                    children: link.label
                }, idx)),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-center border-2 border-red-500 rounded-full py-1 px-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoSearchOutline, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        className: "bg-white outline-none"
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
;// CONCATENATED MODULE: ./components/layout/FloatingNavbar.tsx



const FloatingNavbar = ({ show  })=>{
    return /*#__PURE__*/ _jsx("div", {
        className: `${show ? " block translate-y-0" : "-translate-y-24"} fixed top-0 z-50 flex h-[90px] w-full transform items-start bg-gray-200 px-10 pt-1 duration-200`,
        children: /*#__PURE__*/ _jsxs("div", {
            className: "flex w-full items-center py-2",
            children: [
                /*#__PURE__*/ _jsx("h3", {
                    className: "mr-20 text-3xl text-pink-500",
                    children: "MiMall"
                }),
                /*#__PURE__*/ _jsx("div", {
                    className: "flex w-full justify-center",
                    children: /*#__PURE__*/ _jsxs("div", {
                        className: "relative flex w-full max-w-2xl items-center justify-center rounded-full border-2 bg-white px-4",
                        children: [
                            /*#__PURE__*/ _jsx("input", {
                                type: "text",
                                className: "flex-1 py-1 px-2 outline-none",
                                placeholder: "Search for product..."
                            }),
                            /*#__PURE__*/ _jsx(BiSearch, {
                                className: "w-10 shrink-0 text-2xl text-gray-500"
                            })
                        ]
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: external "react-icons/ci"
var ci_ = __webpack_require__(8625);
// EXTERNAL MODULE: external "react-icons/ti"
var ti_ = __webpack_require__(1946);
;// CONCATENATED MODULE: ./components/layout/MainNavbar.tsx






const MainNavbar = ({ show  })=>{
    return /*#__PURE__*/ _jsx("div", {
        className: `fixed ${show ? "top-[52px]" : "top-0"} w-full bg-gray-900 px-10 duration-200`,
        children: /*#__PURE__*/ _jsxs("div", {
            className: "flex items-center justify-between py-2",
            children: [
                /*#__PURE__*/ _jsx("h3", {
                    className: `fixed text-3xl text-pink-500`,
                    children: "MiMall"
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "flex items-center space-x-5",
                    children: [
                        /*#__PURE__*/ _jsx(CiUser, {
                            className: "cursor-pointer text-3xl text-pink-500"
                        }),
                        /*#__PURE__*/ _jsx(BsHeart, {
                            className: "cursor-pointer text-2xl text-pink-500"
                        }),
                        /*#__PURE__*/ _jsxs(Link, {
                            href: `/cart`,
                            className: "relative",
                            children: [
                                /*#__PURE__*/ _jsx(TiShoppingCart, {
                                    className: "cursor-pointer text-3xl text-pink-500"
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: "absolute -top-1.5 -right-1.5 flex h-5  w-5 items-center justify-center rounded-full bg-[red]",
                                    children: /*#__PURE__*/ _jsx("span", {
                                        className: "text-[10px] text-white",
                                        children: "20"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/layout/NavItem.tsx



const NavItem_NavItem = ({ label , link  })=>{
    return /*#__PURE__*/ _jsx("li", {
        className: "px-4 cursor-pointer hover:text-pink-500 hover:scale-105 duration-200",
        children: /*#__PURE__*/ _jsx(Link, {
            href: link,
            children: label
        })
    });
};

;// CONCATENATED MODULE: ./components/layout/Navbar.tsx



const Navbar = ()=>{
    const { pathname  } = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container mx-auto pt-16",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `flex h-14 w-full items-center justify-between  bg-gray-800 px-5
      `,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "space-x-3 text-pink-500",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/`,
                        children: "All"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/markets/amamoma`,
                        children: "Amamoma"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/markets/apewosika`,
                        children: "Apewosika"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/markets/ayensu`,
                        children: "Ayensu"
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/layout/SearchBar.tsx








const SearchBar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `fixed z-50 h-16 w-full cursor-pointer p-5 shadow-lg`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/images/search-bg.jpg",
                className: "absolute object-cover duration-500",
                fill: true,
                alt: ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute inset-0 h-full w-full bg-black opacity-60"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative z-10 flex h-full w-full flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative flex w-full max-w-2xl items-center rounded-full border-2 bg-white px-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                className: "flex-1 p-2 outline-none",
                                placeholder: "Search for product..."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiSearch, {
                                className: "w-10 shrink-0 text-3xl text-gray-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute right-5 flex items-center space-x-5 text-pink-500",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ci_.CiUser, {
                                className: "cursor-pointer text-3xl "
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsHeart, {
                                className: "cursor-pointer text-2xl "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: `/cart`,
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ti_.TiShoppingCart, {
                                        className: "cursor-pointer text-3xl "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute -right-1.5 -top-1.5 flex h-5  w-5 items-center justify-center rounded-full bg-[red]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-[10px] text-white",
                                            children: "20"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/layout/SectionHeader.tsx


const SectionHeader = ({ label  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between border-b-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "sh-underline relative md:text-3xl",
                children: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                className: "cursor-pointer font-bold text-orange-500",
                children: "See more..."
            })
        ]
    });
};

// EXTERNAL MODULE: external "react-icons/cg"
var cg_ = __webpack_require__(7865);
// EXTERNAL MODULE: ./utils/menus.ts
var menus = __webpack_require__(1437);
;// CONCATENATED MODULE: ./components/layout/SubNavbar.tsx







const SubNavbar_menus = [
    {
        label: "Home",
        link: "/"
    },
    {
        label: "Sell",
        link: "/sell"
    },
    {
        label: "Advertise",
        link: "/advertise"
    },
    {
        label: "Help",
        link: "/help"
    }
];
const SubNavbar = ()=>{
    const [open, setOpen] = useState(false);
    const [openHelp, setOpenHelp] = useState(false);
    const menuRef = useRef(null);
    const btnRef = useRef(null);
    const { push  } = useRouter();
    useEffect(()=>{
        const handler = (e)=>{
            if (e.target instanceof HTMLElement && btnRef.current?.contains(e.target)) return;
            if (e.target instanceof HTMLElement && !menuRef.current?.contains(e.target)) {
                setOpen(false);
            }
        };
        document.addEventListener("mousedown", handler);
        return ()=>{
            document.removeEventListener("mousedown", handler);
        };
    });
    const handleCloseMenu = (link)=>{
        push(`/markets/${link}`).catch((error)=>console.log(error));
        setOpen(false);
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "bg-gray-300 px-2",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "relative mx-auto flex max-w-7xl justify-between py-3",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "flex cursor-pointer items-center space-x-2",
                    onClick: ()=>setOpen(!open),
                    ref: btnRef,
                    children: [
                        /*#__PURE__*/ _jsx(BiMenu, {
                            className: "text-2xl"
                        }),
                        /*#__PURE__*/ _jsx("span", {
                            className: "",
                            children: "Markets Near You"
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx("div", {
                    ref: menuRef,
                    className: `absolute top-12 z-50 w-full max-w-fit border bg-white py-2 text-gray-800 shadow-md duration-500
          ${open ? "visible translate-y-0 opacity-100" : "invisible translate-y-2 opacity-0"}
        `,
                    children: locations.slice(1).map((location, idx)=>/*#__PURE__*/ _jsx("div", {
                            className: `cursor-pointer px-7 py-2 duration-500 hover:bg-[#ff0000] hover:text-white
              ${open ? "opacity-100" : "opacity-0"}
              `,
                            onClick: ()=>handleCloseMenu(location.link),
                            children: location.label
                        }, idx))
                }),
                /*#__PURE__*/ _jsx(CgMenuRightAlt, {
                    onClick: ()=>setOpenHelp(!openHelp),
                    className: "text-2xl md:hidden"
                }),
                /*#__PURE__*/ _jsx("div", {
                    // ref={menuRef}
                    className: `absolute top-12 right-0.5 z-10 w-full max-w-fit border bg-gray-300 py-2 text-gray-800 shadow-md duration-500
          ${openHelp ? "visible translate-y-0 opacity-100" : "invisible translate-y-2 opacity-0"}
        `,
                    children: SubNavbar_menus.map((menu, idx)=>/*#__PURE__*/ _jsx("div", {
                            className: `cursor-pointer px-7 py-2 duration-500 hover:bg-[#ff0000] hover:text-white
              ${openHelp ? "opacity-100" : "opacity-0"}
              `,
                            children: menu.label
                        }, idx))
                }),
                /*#__PURE__*/ _jsx("div", {
                    className: "hidden md:block",
                    children: /*#__PURE__*/ _jsx("ul", {
                        className: "flex divide-x divide-gray-500",
                        children: SubNavbar_menus.map((menu, index)=>/*#__PURE__*/ _jsx(NavItem, {
                                label: menu.label,
                                link: menu.link
                            }, index))
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/layout/index.ts










/***/ }),

/***/ 1437:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kl": () => (/* binding */ locations)
/* harmony export */ });
/* unused harmony exports adminMenus, shopMenus */
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1946);
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ti__WEBPACK_IMPORTED_MODULE_4__);





const adminMenus = [
    {
        name: "Dashboard",
        link: "/admin",
        icon: react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineDashboard
    },
    {
        name: "Administrators",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiShoppingBag,
        subLinks: [
            {
                name: "Administrators List",
                link: "/admin/administrators"
            },
            {
                name: "Add Administrator",
                link: "/admin/administrators/add"
            }
        ]
    },
    {
        name: "Products",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiShoppingBag,
        subLinks: [
            {
                name: "Product List",
                link: "/admin/products"
            },
            {
                name: "Add Product",
                link: "/admin/products/add"
            }
        ]
    },
    {
        name: "Shops",
        icon: react_icons_bs__WEBPACK_IMPORTED_MODULE_0__.BsShop,
        subLinks: [
            {
                name: "Shop List",
                link: "/admin/shops"
            },
            {
                name: "Add Shop",
                link: "/admin/shops/add"
            }
        ]
    },
    {
        name: "Shop Owners",
        icon: react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaUsers,
        subLinks: [
            {
                name: "Shop Owners List",
                link: "/admin/shop-owners"
            },
            {
                name: "Add Shop Owner",
                link: "/admin/shop-owners/add"
            }
        ]
    },
    {
        name: "Orders",
        icon: react_icons_ti__WEBPACK_IMPORTED_MODULE_4__.TiShoppingCart,
        subLinks: [
            {
                name: "Order List",
                link: "/admin/orders"
            }
        ]
    }
];
const shopMenus = [
    {
        name: "Dashboard",
        link: "/shop",
        icon: react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineDashboard
    },
    {
        name: "Products",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiShoppingBag,
        subLinks: [
            {
                name: "Product List",
                link: "/shop/products"
            },
            {
                name: "Add Product",
                link: "/shop/products/add-product"
            }
        ]
    },
    {
        name: "Orders",
        icon: react_icons_ti__WEBPACK_IMPORTED_MODULE_4__.TiShoppingCart,
        subLinks: [
            {
                name: "Order List",
                link: "/shop/orders"
            },
            {
                name: "Order Details",
                link: "/shop/orders/1"
            }
        ]
    }
];
const locations = [
    {
        label: "Select Location",
        link: ""
    },
    {
        label: "Amamoma",
        link: "amamoma"
    },
    {
        label: "Apewosika",
        link: "apewosika"
    },
    {
        label: "Ayensu",
        link: "ayensu"
    },
    {
        label: "Duakro",
        link: "duakro"
    },
    {
        label: "KNH",
        link: "knh"
    },
    {
        label: "Kokoado",
        link: "kokoado"
    },
    {
        label: "Kwasipra",
        link: "kwasipra"
    },
    {
        label: "New Site",
        link: "new-site"
    },
    {
        label: "Old Site",
        link: "old-site"
    },
    {
        label: "Science",
        link: "science"
    }
];


/***/ })

};
;